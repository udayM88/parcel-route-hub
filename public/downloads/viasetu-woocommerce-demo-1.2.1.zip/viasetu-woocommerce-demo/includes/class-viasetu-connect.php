<?php
defined( 'ABSPATH' ) || exit;

final class ViaSetu_Connect {
    const TRANSIENT_PREFIX = 'viasetu_wc_connect_';
    const PROOF_PREFIX = 'viasetu_wc_connect_proof_';

    public static function init() {
        add_action( 'admin_post_viasetu_connect_start', array( __CLASS__, 'start' ) );
        add_action( 'admin_post_viasetu_connect_callback', array( __CLASS__, 'callback' ) );
        add_action( 'admin_post_viasetu_disconnect', array( __CLASS__, 'disconnect' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route(
            'viasetu/v1',
            '/connect-proof',
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'connect_proof' ),
                'permission_callback' => '__return_true',
            )
        );
    }

    private static function proof_key( $state ) {
        return self::PROOF_PREFIX . hash( 'sha256', (string) $state );
    }

    private static function proof_response( $valid, $status ) {
        $response = new WP_REST_Response( array( 'valid' => (bool) $valid ), (int) $status );
        $response->header( 'Cache-Control', 'no-store, max-age=0' );
        return $response;
    }

    public static function connect_proof( WP_REST_Request $request ) {
        $state       = sanitize_text_field( (string) $request->get_param( 'state' ) );
        $challenge   = sanitize_text_field( (string) $request->get_param( 'code_challenge' ) );
        $environment = sanitize_key( (string) $request->get_param( 'environment' ) );
        if ( ! preg_match( '/^[A-Za-z0-9_-]{32,128}$/', $state ) || ! preg_match( '/^[A-Za-z0-9_-]{43,128}$/', $challenge ) ) {
            return self::proof_response( false, 400 );
        }
        $proof = get_transient( self::proof_key( $state ) );
        $valid = is_array( $proof )
            && isset( $proof['state'], $proof['code_challenge'], $proof['environment'], $proof['created_at'] )
            && hash_equals( (string) $proof['state'], $state )
            && hash_equals( (string) $proof['code_challenge'], $challenge )
            && hash_equals( (string) $proof['environment'], $environment )
            && time() - (int) $proof['created_at'] <= 600;
        return self::proof_response( $valid, $valid ? 200 : 403 );
    }

    private static function require_admin() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to connect ViaSetu.', 'viasetu-woocommerce' ) );
        }
    }

    private static function notice( $message, $type = 'success' ) {
        set_transient(
            'viasetu_wc_notice_' . get_current_user_id(),
            array( 'message' => sanitize_text_field( $message ), 'type' => sanitize_key( $type ) ),
            60
        );
    }

    private static function redirect_connection() {
        wp_safe_redirect( admin_url( 'admin.php?page=viasetu&tab=connection' ) );
        exit;
    }

    private static function callback_url() {
        return admin_url( 'admin-post.php?action=viasetu_connect_callback' );
    }

    private static function site_url() {
        return untrailingslashit( home_url( '/' ) );
    }

    private static function environment() {
        return ViaSetu_Settings::package_environment();
    }

    public static function one_click_available() {
        return is_ssl() && 0 === strpos( self::site_url(), 'https://' );
    }

    public static function start_url() {
        return wp_nonce_url( admin_url( 'admin-post.php?action=viasetu_connect_start' ), 'viasetu_connect_start' );
    }

    public static function disconnect_url() {
        return wp_nonce_url( admin_url( 'admin-post.php?action=viasetu_disconnect' ), 'viasetu_disconnect' );
    }

    public static function start() {
        self::require_admin();
        check_admin_referer( 'viasetu_connect_start' );

        if ( ! ViaSetu_Settings::encryption_available() ) {
            self::notice( __( 'Connection stopped because this server cannot encrypt credentials. Enable Sodium or OpenSSL.', 'viasetu-woocommerce' ), 'error' );
            self::redirect_connection();
        }

        if ( ! self::one_click_available() ) {
            $message = ViaSetu_Settings::is_sandbox_package()
                ? __( 'One-click sign-in requires an HTTPS staging URL. For localhost, paste the demo merchant account\'s dedicated vs_test_ key in manual setup.', 'viasetu-woocommerce' )
                : __( 'A production ViaSetu connection requires WordPress and Home URLs to use HTTPS.', 'viasetu-woocommerce' );
            self::notice( $message, 'error' );
            self::redirect_connection();
        }

        $state     = wp_generate_password( 48, false, false );
        $verifier  = wp_generate_password( 64, false, false );
        $challenge = rtrim( strtr( base64_encode( hash( 'sha256', $verifier, true ) ), '+/', '-_' ), '=' );
        $request   = array(
            'state'         => $state,
            'code_verifier' => $verifier,
            'site_url'      => self::site_url(),
            'redirect_uri'  => self::callback_url(),
            'webhook_url'   => rest_url( 'viasetu/v1/webhook' ),
            'environment'   => self::environment(),
            'created_at'    => time(),
        );
        set_transient( self::TRANSIENT_PREFIX . get_current_user_id(), $request, 10 * MINUTE_IN_SECONDS );
        set_transient(
            self::proof_key( $state ),
            array(
                'state'          => $state,
                'code_challenge' => $challenge,
                'environment'    => $request['environment'],
                'created_at'     => $request['created_at'],
            ),
            10 * MINUTE_IN_SECONDS
        );

        $url = add_query_arg(
            array(
                'site_url'       => $request['site_url'],
                'redirect_uri'   => $request['redirect_uri'],
                'webhook_url'    => $request['webhook_url'],
                'code_challenge' => $challenge,
                'state'          => $state,
                'store_name'     => get_bloginfo( 'name' ) ?: wp_parse_url( home_url(), PHP_URL_HOST ),
                'environment'    => $request['environment'],
                'plugin_version' => VIASETU_WC_VERSION,
            ),
            ViaSetu_Settings::get( 'connect_portal_url' )
        );
        wp_redirect( esc_url_raw( $url ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- intentional cross-origin merchant authorization.
        exit;
    }

    public static function callback() {
        self::require_admin();
        $saved = get_transient( self::TRANSIENT_PREFIX . get_current_user_id() );
        $state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );
        $code  = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) );
        if ( ! is_array( $saved ) || ! $state || ! $code || ! hash_equals( (string) $saved['state'], $state ) || time() - (int) $saved['created_at'] > 600 ) {
            self::notice( __( 'The ViaSetu connection link is invalid or expired. Start again.', 'viasetu-woocommerce' ), 'error' );
            self::redirect_connection();
        }
        delete_transient( self::TRANSIENT_PREFIX . get_current_user_id() );
        delete_transient( self::proof_key( $state ) );

        $response = wp_safe_remote_post(
            ViaSetu_Settings::get( 'connect_endpoint' ),
            array(
                'headers'             => array( 'Content-Type' => 'application/json' ),
                'body'                => wp_json_encode(
                    array(
                        'action'        => 'exchange',
                        'code'          => $code,
                        'code_verifier' => $saved['code_verifier'],
                        'site_url'      => $saved['site_url'],
                        'redirect_uri'  => $saved['redirect_uri'],
                        'webhook_url'   => $saved['webhook_url'],
                        'environment'   => $saved['environment'],
                    )
                ),
                'timeout'             => 20,
                'redirection'         => 0,
                'limit_response_size' => 128 * KB_IN_BYTES,
            )
        );
        if ( is_wp_error( $response ) ) {
            ViaSetu_Logger::log( 'error', 'Store connection exchange failed', array( 'error' => $response->get_error_message() ) );
            self::notice( __( 'ViaSetu could not complete the secure connection. Try again.', 'viasetu-woocommerce' ), 'error' );
            self::redirect_connection();
        }
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) || empty( $data['success'] ) || empty( $data['api_key'] ) || empty( $data['webhook_secret'] ) ) {
            self::notice( sanitize_text_field( $data['error'] ?? __( 'ViaSetu rejected the connection request.', 'viasetu-woocommerce' ) ), 'error' );
            self::redirect_connection();
        }
        if ( ! ViaSetu_Settings::store_connection( $data['api_key'], $data['webhook_secret'], $data['connection_id'] ?? '', $data['environment'] ?? 'live', $data['merchant'] ?? array() ) ) {
            self::notice( __( 'The store was authorized but the returned credentials were incomplete, malformed or could not be encrypted. Reconnect and do not paste a shortened key.', 'viasetu-woocommerce' ), 'error' );
            self::redirect_connection();
        }
        $verification = ( new ViaSetu_Api_Client() )->account();
        if ( is_wp_error( $verification ) ) {
            ViaSetu_Settings::mark_connection_checked( false, $verification->get_error_message() );
            ViaSetu_Logger::log( 'error', 'WooCommerce connection created but verification failed', array( 'error' => $verification->get_error_message() ) );
            self::notice( sprintf( __( 'The store key was saved, but ViaSetu could not verify it: %s', 'viasetu-woocommerce' ), $verification->get_error_message() ), 'error' );
            self::redirect_connection();
        }
        ViaSetu_Logger::log( 'success', 'WooCommerce store connected to merchant account' );
        self::notice( __( 'ViaSetu Merchant is connected. Orders, billing, labels and tracking are ready.', 'viasetu-woocommerce' ) );
        self::redirect_connection();
    }

    public static function disconnect() {
        self::require_admin();
        check_admin_referer( 'viasetu_disconnect' );
        if ( ViaSetu_Settings::api_key() ) {
            $result = ( new ViaSetu_Api_Client() )->disconnect();
            if ( is_wp_error( $result ) ) {
                self::notice( sprintf( __( 'ViaSetu could not revoke this connection: %s', 'viasetu-woocommerce' ), $result->get_error_message() ), 'error' );
                self::redirect_connection();
            }
        }
        ViaSetu_Settings::clear_connection();
        ViaSetu_Logger::log( 'success', 'WooCommerce store disconnected' );
        self::notice( __( 'ViaSetu Merchant was disconnected and its local credentials were removed.', 'viasetu-woocommerce' ) );
        self::redirect_connection();
    }
}
